import json
import os
import boto3
import hashlib
import hmac
from botocore.exceptions import ClientError

# DynamoDB bağlantısını oluştur
dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')

# Kullanıcılar tablosu
USERS_TABLE = dynamodb.Table('Users')

# Güvenli bir salt değeri
SALT = "CustomerServiceSalt123"  

def hash_password(password):
    """Şifreyi güvenli bir şekilde hashle"""
    # String olarak SALT ve password'ü birleştir
    salted = (SALT + password).encode('utf-8')
    # SHA-256 hash oluştur
    return hashlib.sha256(salted).hexdigest()

def check_password(input_password, stored_hash):
    """Şifrenin doğruluğunu kontrol et"""
    # Girilen şifreyi aynı yöntemle hashle
    input_hash = hash_password(input_password)
    # Hash'leri karşılaştır
    return input_hash == stored_hash

def register(event):
    """Kullanıcı kayıt işlemi"""
    try:
        # Request body'den kullanıcı bilgilerini al
        body = json.loads(event['body'])
        email = body['email']
        password = body['password']

        # Şifre karmaşıklık kontrolü
        if len(password) < 8:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST'
                },
                'body': json.dumps({'message': 'Şifre en az 8 karakter olmalıdır.'})
            }

        # E-posta kontrolü
        try:
            response = USERS_TABLE.get_item(Key={'email': email})
            if 'Item' in response:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST'
                    },
                    'body': json.dumps({'message': 'Bu e-posta adresi zaten kayıtlı.'})
                }
        except ClientError as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST'
                },
                'body': json.dumps({'message': str(e)})
            }

        # Şifreyi hashle ve kullanıcıyı kaydet
        hashed_password = hash_password(password)
        
        USERS_TABLE.put_item(
            Item={
                'email': email,
                'password': hashed_password
            }
        )

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': json.dumps({'message': 'Kullanıcı başarıyla kaydedildi.', 'email': email})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': json.dumps({'message': str(e)})
        }

def login(event):
    """Kullanıcı giriş işlemi"""
    try:
        # Request body'den kullanıcı bilgilerini al
        body = json.loads(event['body'])
        email = body['email']
        password = body['password']

        # Kullanıcıyı bul
        try:
            response = USERS_TABLE.get_item(Key={'email': email})
            
            if 'Item' not in response:
                return {
                    'statusCode': 404,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST'
                    },
                    'body': json.dumps({'message': 'Kullanıcı bulunamadı.'})
                }

            user = response['Item']
            
            # Şifre kontrolü
            if check_password(password, user['password']):
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST'
                    },
                    'body': json.dumps({
                        'message': 'Giriş başarılı.',
                        'email': user['email']
                    })
                }
            else:
                return {
                    'statusCode': 401,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST'
                    },
                    'body': json.dumps({'message': 'Hatalı şifre.'})
                }

        except ClientError as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST'
                },
                'body': json.dumps({'message': str(e)})
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': json.dumps({'message': str(e)})
        }

def lambda_handler(event, context):
    """Ana Lambda handler fonksiyonu"""
    
    # OPTIONS isteği için CORS desteği
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': json.dumps({})
        }
    
    # API Gateway'den gelen istekler için
    if 'httpMethod' in event and 'path' in event:
        http_method = event.get('httpMethod', '')
        path = event.get('path', '').rstrip('/')
        
        if http_method == 'POST':
            if path == '/register':
                return register(event)
            elif path == '/login':
                return login(event)
    # Doğrudan test için
    else:
        # Test olayı için varsayılan olarak register fonksiyonunu çağır
        return register(event)
    
    # Desteklenmeyen endpoint
    return {
        'statusCode': 404,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'OPTIONS,POST'
        },
        'body': json.dumps({'message': 'Endpoint bulunamadı'})
    } 